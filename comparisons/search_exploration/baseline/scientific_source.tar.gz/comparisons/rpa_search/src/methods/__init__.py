"""Benchmark search method implementations."""
