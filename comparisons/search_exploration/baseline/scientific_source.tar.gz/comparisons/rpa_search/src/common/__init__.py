"""Common benchmark components."""
