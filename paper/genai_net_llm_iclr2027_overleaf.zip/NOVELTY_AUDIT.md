# Novelty audit

Snapshot date: 21 August 2026. This audit records a focused search, not a legal
prior-art opinion or a guarantee that no uncatalogued concurrent work exists.

## Bottom line

The work belongs in the same broad family as OPRO, FunSearch, AlphaEvolve,
Eureka, and simulator-grounded scientific agents. It should not claim to invent
LLM proposal operators, evaluator-guided generation, persistent candidate
databases, LLM-plus-RL systems, or LLM-assisted genetic-circuit design.

The defensible contribution is the combination and its controlled evaluation:

1. An independently learning RL optimizer and an external LLM proposal operator
   remain active concurrently.
2. Simulator-grounded state flows outward while structured candidate batches flow
   inward through an auditable persistent workspace.
3. Both proposal sources use one canonical evaluator and one fixed candidate
   budget, with immutable initial-source and temporal provenance.
4. The system is evaluated for inverse dynamical CRN design across paired seeds,
   model classes, task families, source prevalence, diversity, latency, and cost.

Current confidence is **moderate** for algorithmic novelty and **moderate-to-high**
for domain-specific empirical novelty. The evidence below is needed to make that
position robust at review.

## Closest systems

| Work | Existing overlap | Remaining distinction |
| --- | --- | --- |
| OPRO | LLM sees prior solutions and objective values | No concurrently learning RL proposal channel or CRN simulator study |
| FunSearch | LLM proposals, evaluator, high-score database | Program search rather than hybrid RL/LLM dynamical-network search |
| AlphaEvolve | Multi-model proposals, evaluators, evolutionary database | Evolves code; does not test a concurrently learning domain optimizer under a shared CRN evaluation budget |
| Eureka | Batched LLM generation, simulator statistics, RL training | LLM evolves the reward used to train RL; it does not contribute candidate solutions alongside RL |
| Scientific Generative Agent | LLM discrete hypotheses plus simulator-based continuous optimization | Bilevel LLM-centered optimization rather than asynchronous dual proposal sources |
| CELLM | LLM-assisted synthetic genetic-circuit design | Natural-language-to-Cello interface, not dynamical CRN topology/parameter search with RL |
| GenAI-Net | RL-based inverse CRN design with simulation | No LLM proposal source or full-duplex workspace protocol |

## Claims to avoid

- "The first use of an LLM for optimization."
- "The first LLM proposal or mutation operator."
- "The first evaluator-grounded LLM search."
- "The first combination of LLMs and reinforcement learning."
- "The first LLM system for genetic-circuit design."
- "Full-duplex" as if the communication term itself were invented here.

## Claims that may survive review

- A full-duplex, simulator-in-the-loop coupling of concurrent RL and LLM proposal
  channels for inverse dynamical CRN design.
- A budget-matched empirical study of whether LLM proposals improve a learned CRN
  search policy, including immutable source provenance and delayed merge timing.
- Evidence about when LLM candidates directly dominate, seed later RL search, or
  collapse onto shared biological motifs.
- A reproducibility comparison between hosted model tiers and fixed local models.

Use "to our knowledge" only after repeating the search immediately before
submission. Prefer concrete comparisons over first-of-kind language.

## Decisive validation

1. **Matched random proposals:** compare each LLM batch with valid random
   candidates matched for task, reaction count, and batch size.
2. **Feedback corruption:** permute candidate losses within frozen workspaces and
   test whether proposal quality degrades. This distinguishes use of simulator
   evidence from generic pretrained priors.
3. **Half-duplex counterfactual:** use request issue/merge timestamps to report
   blocked wall time and time-to-target had RL waited for every response.
4. **Optional synchronous cohort:** run a small paired cohort only if trace replay
   cannot identify the quality effect of stale versus immediate feedback.
5. **Long horizon:** verify that gains persist when the baseline receives the
   original 300-epoch horizon.
6. **Breadth and local models:** establish that the finding is not specific to two
   tasks or one proprietary service snapshot.

## Search refresh checklist

- Search arXiv, OpenReview, Crossref, Semantic Scholar, and Google Scholar for
  combinations of: LLM, proposal operator, asynchronous, reinforcement learning,
  simulator feedback, scientific optimization, CRN, genetic circuit, and
  biomolecular network design.
- Forward- and backward-chain citations from AlphaEvolve, Eureka, CELLM, OPRO,
  FunSearch, and Scientific Generative Agent.
- Check ICLR 2027 submissions and papers published after 17 July 2026 even when a
  formal comparison is not required.
- Record query strings, dates, inclusion decisions, and stable identifiers.
