# Figure plan

The current files are a dated interim preview generated from completed Flash and
archived baseline artifacts. Regenerate every figure from frozen campaign
artifacts before submission.

Planned figures:

1. `architecture.pdf`: asynchronous RL/LLM/SIL data flow.
2. `primary_performance.pdf`: budget-matched logic and RPA performance.
3. `performance_diversity.pdf`: diversity shown jointly with performance.
4. `source_prevalence.pdf`: LLM/RL provenance and loss through epochs.
5. `request_analysis.pdf`: request utility, tool use, and segment effects.
6. `resource_quality.pdf`: cost, latency, tokens, and performance.
7. `representative_crns.pdf`: reaction diagrams and trajectories.
