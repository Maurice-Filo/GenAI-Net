# GenAI-Net-LLM ICLR 2027 primer

This directory is an anonymous, compilable manuscript scaffold for the
GenAI-Net-LLM study. The 21 August 2026 preview includes completed Flash results;
red `TODO` and bracketed text mark unfinished cohorts or manuscript work.

## Build

```bash
make
```

The compiled manuscript is `build/main.pdf`.

## Structure

- `main.tex`: title, temporary abstract, section order, and bibliography.
- `macros.tex`: method names and visible placeholder helpers.
- `sections/`: modular manuscript and appendix text.
- `references.bib`: curated starter bibliography with verified primary records.
- `LITERATURE_NOTES.md`: positioning map and closest prior work.
- `NOVELTY_AUDIT.md`: claim boundaries, closest systems, and decisive controls.
- `style/`: unmodified official ICLR 2027 style files downloaded from ICLR.
- `figures/`: destination for regenerated, submission-quality figures.

## Before submission

1. Replace every `TODO` and placeholder after freezing the analysis.
2. Regenerate all figures from the final immutable campaign artifacts.
3. Complete Pro, local-model, long-horizon, breadth, RAG, and exclusion cohorts.
4. Freeze the statistical analysis and report paired uncertainty/effect sizes.
5. Expand and manually verify the primary-source bibliography.
6. Add anonymous code/artifact links and exact reproduction commands.
7. Update the required AI use statement and review anonymity.
8. Confirm the main text remains within the ICLR submission page limit.
